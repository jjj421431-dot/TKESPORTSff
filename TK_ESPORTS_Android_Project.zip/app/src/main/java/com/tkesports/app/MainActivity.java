package com.tkesports.app;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    LinearLayout homePanel, formPanel, dashboardPanel;
    EditText nameInput, emailInput, passwordInput;
    TextView formTitle, dashboardTitle, dashboardText;
    Button actionBtn;
    boolean adminMode = false;
    SharedPreferences prefs;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        prefs = getSharedPreferences("tk_esports", MODE_PRIVATE);

        homePanel = findViewById(R.id.homePanel);
        formPanel = findViewById(R.id.formPanel);
        dashboardPanel = findViewById(R.id.dashboardPanel);
        nameInput = findViewById(R.id.nameInput);
        emailInput = findViewById(R.id.emailInput);
        passwordInput = findViewById(R.id.passwordInput);
        formTitle = findViewById(R.id.formTitle);
        dashboardTitle = findViewById(R.id.dashboardTitle);
        dashboardText = findViewById(R.id.dashboardText);
        actionBtn = findViewById(R.id.actionBtn);

        findViewById(R.id.memberBtn).setOnClickListener(v -> showMember());
        findViewById(R.id.adminBtn).setOnClickListener(v -> showAdmin());
        findViewById(R.id.backBtn).setOnClickListener(v -> showHome());
        findViewById(R.id.logoutBtn).setOnClickListener(v -> showHome());
        findViewById(R.id.tournamentBtn).setOnClickListener(v ->
            Toast.makeText(this, "Tournament section ready for your tournament data.", Toast.LENGTH_LONG).show());
        findViewById(R.id.noticeBtn).setOnClickListener(v ->
            Toast.makeText(this, "No notice yet. Admin can publish notices in the full backend version.", Toast.LENGTH_LONG).show());
    }

    void showHome() {
        homePanel.setVisibility(View.VISIBLE);
        formPanel.setVisibility(View.GONE);
        dashboardPanel.setVisibility(View.GONE);
        clearFields();
    }

    void showMember() {
        adminMode = false;
        homePanel.setVisibility(View.GONE);
        dashboardPanel.setVisibility(View.GONE);
        formPanel.setVisibility(View.VISIBLE);
        formTitle.setText("Member Login / Register");
        nameInput.setVisibility(View.VISIBLE);
        nameInput.setHint("Name (for registration)");
        actionBtn.setText("REGISTER / LOGIN");
        actionBtn.setOnClickListener(v -> memberAuth());
    }

    void showAdmin() {
        adminMode = true;
        homePanel.setVisibility(View.GONE);
        dashboardPanel.setVisibility(View.GONE);
        formPanel.setVisibility(View.VISIBLE);
        formTitle.setText("Admin Login");
        nameInput.setVisibility(View.GONE);
        emailInput.setHint("Admin username");
        passwordInput.setHint("Admin password");
        actionBtn.setText("LOGIN");
        actionBtn.setOnClickListener(v -> adminAuth());
    }

    void adminAuth() {
        String user = emailInput.getText().toString().trim();
        String pass = passwordInput.getText().toString();
        if ((user.equals("admin1") || user.equals("admin2")) && pass.equals("719181")) {
            showDashboard("ADMIN: " + user, "Admin controls are available.\n\nTournament management, members, rooms, results and notices can be connected to a backend.");
        } else {
            Toast.makeText(this, "Wrong admin username or password.", Toast.LENGTH_SHORT).show();
        }
    }

    void memberAuth() {
        String name = nameInput.getText().toString().trim();
        String user = emailInput.getText().toString().trim();
        String pass = passwordInput.getText().toString();
        if (user.isEmpty() || pass.isEmpty()) {
            Toast.makeText(this, "Username and password দিন.", Toast.LENGTH_SHORT).show();
            return;
        }
        if (name.isEmpty()) name = user;
        prefs.edit().putString("member_name", name).putString("member_user", user).apply();
        showDashboard("WELCOME, " + name, "Member account is active.\n\nTournament join, room details, results and notices are ready for connection to the tournament backend.");
    }

    void showDashboard(String title, String text) {
        formPanel.setVisibility(View.GONE);
        homePanel.setVisibility(View.GONE);
        dashboardPanel.setVisibility(View.VISIBLE);
        dashboardTitle.setText(title);
        dashboardText.setText(text);
    }

    void clearFields() {
        nameInput.setText("");
        emailInput.setText("");
        passwordInput.setText("");
    }
}
