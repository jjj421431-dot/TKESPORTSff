# TK ESPORTS — Android APK starter

একটি APK-এর ভিতরে Admin + Member system-এর build-ready starter.

## Login
- Admin usernames: `admin1` অথবা `admin2`
- Admin password: user-provided password (বর্তমান demo build-এ hardcoded)
- Member: username/password দিয়ে local demo registration/login

## Important
এটি একটি **local/offline starter**। একাধিক ফোনে Member/Admin data sync, real tournament management, payment, room distribution, result sync ইত্যাদির জন্য backend/database (যেমন Firebase) যোগ করতে হবে।

## Logo পরিবর্তন
`app/src/main/res/drawable/logo.xml` ফাইল বদলালে app icon/logo পরিবর্তন করা যাবে। PNG/JPG logo ব্যবহার করতে চাইলে `app/src/main/res/drawable/`-এ নতুন image রেখে Android layout/icon reference বদলাতে হবে.

## Build
GitHub Actions workflow: `.github/workflows/build.yml`
Run workflow → build → Artifacts → `TK-ESPORTS-APK`.
